# Data Source

**File:** TataSteel_BRSR_FY2024-25.pdf

**Source:** Official BRSR filing by Tata Steel Limited to BSE and NSE
**Reference:** SEC/373/2025-26
**Date:** June 6, 2025

**Direct link:**
https://www.tatasteel.com/investors/integrated-reportannual-report/118-integrated-annual-report-2024-25

> Place the downloaded BRSR PDF in this folder as `TataSteel_BRSR_FY2024-25.pdf`
